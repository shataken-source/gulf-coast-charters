// __tests__/phase1-testing.js
// Phase 1 Testing Suite - For Friends & Family to Try Breaking the Site!

/**
 * PHASE 1 TESTING INSTRUCTIONS
 * 
 * Hey Testing Team! 🎣
 * 
 * Your mission: Try to BREAK this website! 
 * We want to find all the bugs before real users do.
 * 
 * HOW TO RUN TESTS:
 * 1. Open the website
 * 2. Open browser console (F12 or right-click -> Inspect)
 * 3. Copy and paste test functions into console
 * 4. Watch for red error messages = you found a bug!
 * 
 * REWARD: Find a bug = Get a free fishing trip! 🐟
 */

// ============================================
// TEST SCENARIOS FOR MANUAL TESTING
// ============================================

const PHASE1_TEST_SCENARIOS = {
  // TEENAGER TESTS - Can a 16-year-old use this?
  teenager: [
    {
      id: 'teen-1',
      title: 'Sign Up with Emoji Username',
      steps: [
        '1. Go to Sign Up page',
        '2. Try username: 🎣FishBoi420🔥',
        '3. Use a simple password like "password123"',
        '4. Put fake birthday to be under 18',
        '5. See if it lets you create account'
      ],
      expected: 'Should work but filter inappropriate names',
      severity: 'medium'
    },
    {
      id: 'teen-2',
      title: 'Upload Massive Video',
      steps: [
        '1. Go to create fishing report',
        '2. Try uploading a 500MB video',
        '3. Upload 20 photos at once',
        '4. Use ALL CAPS in the title',
        '5. Submit without filling required fields'
      ],
      expected: 'Should limit file size and require fields',
      severity: 'high'
    },
    {
      id: 'teen-3',
      title: 'Spam the Points System',
      steps: [
        '1. Post 100 comments in 1 minute',
        '2. Like and unlike same post repeatedly',
        '3. Check in multiple times per day',
        '4. Create duplicate accounts for more points',
        '5. Try to give yourself badges'
      ],
      expected: 'Should have rate limiting',
      severity: 'high'
    }
  ],

  // RETIREE TESTS - Can a 75-year-old use this?
  retiree: [
    {
      id: 'retire-1',
      title: 'Book Trip with Confusing Dates',
      steps: [
        '1. Try to book a trip for yesterday',
        '2. Select February 30th',
        '3. Book same trip twice',
        '4. Enter phone: 555-FISHING',
        '5. Pay with expired credit card'
      ],
      expected: 'Should validate all inputs clearly',
      severity: 'critical'
    },
    {
      id: 'retire-2',
      title: 'Lost Password Recovery',
      steps: [
        '1. Click "Forgot Password"',
        '2. Enter wrong email format',
        '3. Enter email that doesn\'t exist',
        '4. Click reset link twice',
        '5. Use back button after reset'
      ],
      expected: 'Should guide through recovery',
      severity: 'high'
    },
    {
      id: 'retire-3',
      title: 'Accessibility Test',
      steps: [
        '1. Use only keyboard (no mouse)',
        '2. Make text super large',
        '3. Turn on high contrast',
        '4. Use screen reader',
        '5. Click tiny buttons'
      ],
      expected: 'Everything should be accessible',
      severity: 'high'
    }
  ],

  // CHAOS TESTS - Try to break everything!
  chaos: [
    {
      id: 'chaos-1',
      title: 'Database Overload',
      steps: [
        '1. Open site in 10 tabs',
        '2. Login to same account in all tabs',
        '3. Update profile in all tabs at once',
        '4. Book same trip in multiple tabs',
        '5. Refresh rapidly while loading'
      ],
      expected: 'Should handle concurrent access',
      severity: 'critical'
    },
    {
      id: 'chaos-2',
      title: 'Input Injection Attacks',
      steps: [
        '1. Put HTML in name: <script>alert("hacked")</script>',
        '2. SQL in search: \'; DROP TABLE users; --',
        '3. Giant text: Copy entire Wikipedia article',
        '4. Special chars: 😈👹🔥💀☠️',
        '5. Negative numbers in payment'
      ],
      expected: 'Should sanitize all inputs',
      severity: 'critical'
    },
    {
      id: 'chaos-3',
      title: 'Network Chaos',
      steps: [
        '1. Start booking, disconnect internet',
        '2. Submit form with throttled connection',
        '3. Upload photo, cancel midway',
        '4. Timeout during payment',
        '5. Use site on 2G connection'
      ],
      expected: 'Should handle network issues gracefully',
      severity: 'high'
    }
  ],

  // PAYMENT TESTS - Money stuff must work!
  payment: [
    {
      id: 'pay-1',
      title: 'Payment Edge Cases',
      steps: [
        '1. Pay with test card: 4242 4242 4242 4242',
        '2. Try card: 4000 0000 0000 0002 (decline)',
        '3. Enter amount: $0.01',
        '4. Enter amount: $999,999',
        '5. Pay in different currency'
      ],
      expected: 'Should handle all payment scenarios',
      severity: 'critical'
    },
    {
      id: 'pay-2',
      title: 'Refund Process',
      steps: [
        '1. Book trip and pay',
        '2. Cancel immediately',
        '3. Cancel 23 hours before',
        '4. Cancel after trip date',
        '5. Request double refund'
      ],
      expected: 'Should follow refund policy',
      severity: 'critical'
    }
  ],

  // MOBILE TESTS - Works on phones?
  mobile: [
    {
      id: 'mobile-1',
      title: 'Mobile Responsiveness',
      steps: [
        '1. Open on iPhone Safari',
        '2. Open on Android Chrome',
        '3. Rotate screen while booking',
        '4. Pinch zoom on payment page',
        '5. Use in airplane mode'
      ],
      expected: 'Should work on all devices',
      severity: 'high'
    },
    {
      id: 'mobile-2',
      title: 'Touch Interactions',
      steps: [
        '1. Double tap everything',
        '2. Long press on buttons',
        '3. Swipe instead of scroll',
        '4. Fat finger multiple buttons',
        '5. Use with gloves on'
      ],
      expected: 'Touch targets should be large enough',
      severity: 'medium'
    }
  ]
}

// ============================================
// AUTOMATED TEST FUNCTIONS
// ============================================

/**
 * Run this in browser console to stress test
 */
function stressTestBooking() {
  console.log('🎣 Starting Booking Stress Test...')
  
  const promises = []
  for (let i = 0; i < 10; i++) {
    promises.push(
      fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tripId: 'test-trip-' + i,
          date: '2024-12-25',
          passengers: 99,
          name: 'Test User ' + i,
          email: `test${i}@test.com`
        })
      })
    )
  }
  
  Promise.all(promises)
    .then(responses => {
      console.log('✅ Stress test complete!')
      responses.forEach(r => console.log('Response:', r.status))
    })
    .catch(err => {
      console.error('❌ Stress test failed:', err)
    })
}

/**
 * Test form validation
 */
function testFormValidation() {
  console.log('🎣 Testing Form Validation...')
  
  const badInputs = [
    { field: 'email', value: 'not-an-email' },
    { field: 'phone', value: '123' },
    { field: 'date', value: '2020-01-01' },
    { field: 'passengers', value: -5 },
    { field: 'name', value: '<script>alert("xss")</script>' },
    { field: 'credit_card', value: '1234' }
  ]
  
  badInputs.forEach(input => {
    const field = document.querySelector(`[name="${input.field}"]`)
    if (field) {
      field.value = input.value
      field.dispatchEvent(new Event('blur'))
      console.log(`Testing ${input.field} with:`, input.value)
      
      // Check for error message
      const error = field.parentElement.querySelector('.error-message')
      if (error) {
        console.log('✅ Error shown:', error.textContent)
      } else {
        console.error('❌ No error shown for bad input!')
      }
    }
  })
}

/**
 * Test GPS location sharing
 */
function testLocationSharing() {
  console.log('🎣 Testing Location Sharing...')
  
  // Try to spam location updates
  for (let i = 0; i < 100; i++) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        fetch('/api/location', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            lat: position.coords.latitude + Math.random(),
            lng: position.coords.longitude + Math.random(),
            accuracy: Math.random() * 100
          })
        })
      },
      (error) => console.error('Location error:', error)
    )
  }
}

/**
 * Test points system exploitation
 */
function testPointsExploit() {
  console.log('🎣 Testing Points System...')
  
  // Try to award points directly
  fetch('/api/community', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'awardPoints',
      userId: 'my-user-id',
      points: 999999,
      reason: 'I deserve it'
    })
  }).then(r => {
    if (r.ok) {
      console.error('❌ SECURITY ISSUE: Can award points directly!')
    } else {
      console.log('✅ Points system secure')
    }
  })
}

// ============================================
// TEST RESULT TRACKER
// ============================================

class TestResultTracker {
  constructor() {
    this.results = []
    this.startTime = Date.now()
  }

  recordTest(testId, passed, notes = '') {
    this.results.push({
      testId,
      passed,
      notes,
      timestamp: new Date().toISOString()
    })
    
    console.log(
      passed ? '✅' : '❌',
      testId,
      notes
    )
  }

  generateReport() {
    const duration = Date.now() - this.startTime
    const passed = this.results.filter(r => r.passed).length
    const failed = this.results.filter(r => !r.passed).length
    
    const report = {
      summary: {
        total: this.results.length,
        passed,
        failed,
        duration: `${duration / 1000}s`,
        passRate: `${(passed / this.results.length * 100).toFixed(1)}%`
      },
      results: this.results,
      timestamp: new Date().toISOString()
    }
    
    // Save to localStorage
    localStorage.setItem('phase1-test-results', JSON.stringify(report))
    
    // Display summary
    console.log('📊 TEST REPORT')
    console.log('================')
    console.log(`Total Tests: ${report.summary.total}`)
    console.log(`Passed: ${passed} ✅`)
    console.log(`Failed: ${failed} ❌`)
    console.log(`Pass Rate: ${report.summary.passRate}`)
    console.log(`Duration: ${report.summary.duration}`)
    console.log('================')
    
    // Show failed tests
    if (failed > 0) {
      console.log('Failed Tests:')
      this.results.filter(r => !r.passed).forEach(r => {
        console.log(`  ❌ ${r.testId}: ${r.notes}`)
      })
    }
    
    return report
  }
}

// ============================================
// EASY TEST RUNNER FOR NON-TECHNICAL USERS
// ============================================

/**
 * Super simple test runner that anyone can use
 * Just paste this in console and press Enter!
 */
function runEasyTests() {
  console.log('🎣 Welcome to Gulf Coast Charters Testing!')
  console.log('🐟 Running automatic tests...')
  console.log('=====================================')
  
  const tracker = new TestResultTracker()
  
  // Test 1: Can we reach the website?
  fetch('/api/health')
    .then(r => {
      tracker.recordTest('api-health', r.ok, 'API is responding')
    })
    .catch(() => {
      tracker.recordTest('api-health', false, 'API is not responding')
    })
  
  // Test 2: Check if database is connected
  fetch('/api/db-check')
    .then(r => r.json())
    .then(data => {
      tracker.recordTest('database', data.connected, 'Database connection')
    })
    .catch(() => {
      tracker.recordTest('database', false, 'Database not connected')
    })
  
  // Test 3: Check if weather service works
  fetch('/api/weather/current')
    .then(r => {
      tracker.recordTest('weather', r.ok, 'Weather service working')
    })
    .catch(() => {
      tracker.recordTest('weather', false, 'Weather service down')
    })
  
  // Test 4: Check mobile responsiveness
  const isMobile = window.innerWidth < 768
  tracker.recordTest('mobile', true, `Screen width: ${window.innerWidth}px`)
  
  // Test 5: Check page load time
  const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart
  tracker.recordTest('performance', loadTime < 3000, `Page loaded in ${loadTime}ms`)
  
  // Generate report after all tests
  setTimeout(() => {
    console.log('')
    const report = tracker.generateReport()
    
    // Show friendly message
    if (report.summary.passRate === '100.0') {
      console.log('🎉 PERFECT! Everything is working great!')
      console.log('🐟 The fish are biting and the site is running smooth!')
    } else if (parseFloat(report.summary.passRate) >= 80) {
      console.log('👍 Looking good! Just a few small issues.')
      console.log('🎣 We can still go fishing!')
    } else {
      console.log('⚠️ Hmm, we found some problems.')
      console.log('🔧 Time to fix things before we launch!')
    }
    
    console.log('')
    console.log('📧 Email results to: dev@gulfcoastcharters.com')
    console.log('Or take a screenshot and send to the team!')
  }, 2000)
}

// ============================================
// INSTRUCTIONS FOR TESTERS
// ============================================

const TESTER_INSTRUCTIONS = `
📋 PHASE 1 TESTING CHECKLIST
============================

WHAT YOU NEED:
✓ A computer or phone
✓ Internet connection
✓ 30 minutes of time
✓ Desire to break things!

HOW TO TEST:
1. Open website: https://gulfcoastcharters.com
2. Right-click anywhere → Select "Inspect"
3. Click "Console" tab
4. Copy & paste: runEasyTests()
5. Press Enter
6. Take screenshot of results

MANUAL TESTING (Try to break these):
□ Sign up with crazy username
□ Upload huge files
□ Book impossible dates
□ Enter negative money amounts
□ Click buttons super fast
□ Use site on phone
□ Turn off internet mid-booking
□ Use emojis everywhere
□ Try to hack the points
□ Book same trip twice

FOUND A BUG? 
- Take a screenshot
- Note what you did
- Email: bugs@gulfcoastcharters.com
- Get a FREE fishing trip!

ACCESSIBILITY CHECK:
□ Can you use without mouse?
□ Is text big enough?
□ Do colors have contrast?
□ Does voice reader work?
□ Are errors clear?

Remember: If grandma or a teenager can't use it, it needs fixing!
`

// Print instructions
console.log(TESTER_INSTRUCTIONS)

// Export for use
export {
  PHASE1_TEST_SCENARIOS,
  TestResultTracker,
  runEasyTests,
  stressTestBooking,
  testFormValidation,
  testLocationSharing,
  testPointsExploit
}
